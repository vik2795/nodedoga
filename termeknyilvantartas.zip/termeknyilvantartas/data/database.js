import sqlite from "sqlite3";

const db= new sqlite.Database("./data/database.sqlite");

async function initialize()
{
    await dbRun("CREATE TABLE IF NOT EXIST termekek(id INTEGER PRIMARY KEY AUTOINCREMENT,name STRING, brand STRING, description TEXT,price INTEGER");

    await dbRun('INSERT INTO termekek(name,brand,description,price) VALUES ("Start Wars Millennium Falcon", "Lego", "LEGO - for adults, recommended for ages 18 and up, LEGO® Star Wars series, release year 2024, pack of 921 building blocks", 23760 )');

    await dbRun('INSERT INTO termekek(name,brand,description,price) VALUES ("Elmo Doll", "doll", " The Gund Sesame Street 12 inch Plush Elmo Doll is here to bring joy and cuddles into your childs life. ", 2500 )');

    await dbRun('INSERT INTO termekek(name,brand,description,price) VALUES ("Thomas the Tank Engine", "figure", "  Get set for escapades aplenty as Thomas explores his new home and meets some really useful new friends along the way.", 1799 )');
     
}

function dbRun(sql,params=[])
{
    return new Promise((resolve,reject)=>
    {
        db.run(sql,params,function(err){
            if(err){
                reject(err);}
                else{resolve(row);

                }
            });
        }
        );
    }

    function dbGet(sql,params=[])
    {
        return new Promise((resolve,reject)=>
        {
            db.get(sql,params,function(err,row){
                if(err){
                    reject(err);}
                    else{resolve(row);
    
                    }
                });
            }
            );
        }   

    function dbAll(sql,params=[])
    {
    return new Promise((resolve,reject)=>
    {
        db.all(sql,params,function(err,rows){
            if(err){
                reject(err);}
                else{resolve(rows);

                }
            });
        }
        );
    }

    export {dbRun,dbGet,dbAll, initialize}