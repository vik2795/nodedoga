import express, { Router } from "express";
import { dbAll,dbGet,dbRun } from "../data/database.js";

const router=express.router();

router.get("/", async(req,res)=>{
    try{console.log("Get all")
        console.rows=await dbAll("SELECT *FROM termekek");
        console.log('Rows:'+ rows)
        res.status(200).json(rows);
    }
    catch(err)
    {
        console.log(`Error:${err.message}`);
        res.status(500).json({message: err.message});
    }
});
router.post("/", async(req,res)=>{const{name,brand,description,price}=req.body;
if(!name && !brand && !description && !price)
{
    return res.status(400).json({message: "Missing data"});
}
try{const termekek =await dbRun("INSERT INTO termekek(name,brand,description,price)VALUES(?;?;?;?)",[name,brand,description,price]);
    res.status(201).json({message: "Created successful"});

}
catch(err)
{
    res.status(500).json({message: err.message});
}
});

router.get("/:id", async (req,res)=> {try {const termekek=await dbGet("SELECT *FROM termekek WHERE id=?", [req.params.id]);
    if(!termekek)
    {
        return res.status(404).json({message:"A termék nem található"});
        
    }
    res.status(200).json(termekek);
}catch(err){res.status(500).json({message:err.message})}

    
});
router.put("/:id",async(req,res)=>{const termekek={name,brand,description,price}=req.body});
if(!name && !brand && !description && !price ){return res.status(400).json({message:"Missing data"});}
try{const termekek= await dbGet("SELECT *FROM termekek WHERE id=?", [req.params.id]);
    return res.status(404).json({message:"Cannot found"});

await dbRun("UPDATE termekek SET name=? , brand=?, description=?, price=? WHERE id=?", [name,brand,description,price,termekek.id]);
res.status(200).json({message:"Update succesful"})}
catch(err){res.status(500).json({message : err.message})};

router.delete("/:id", async(req,res)=>{try{const termekek=await dbGet("SELECT *FROM termekek WHERE id=?", [req.params.id]);
    if(!termekek)
        {
            return res.status(404).json
        }
    await dbRun("DELETE FROM termekek WHERE id=?",[req.params.id]);

}
catch(err){res.status(500).json({message:err.message})}
});

export default router;

