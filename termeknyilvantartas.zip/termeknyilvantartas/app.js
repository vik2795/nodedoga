import express from 'express';
import cors from ' cors';
import corsRoutes from "./routes/termekek.js";
import {initialize} from "./data/database.js"

const PORT=300;
const app=express();

app.use(cors());
app.use(express.json());
app.use("/termekek",termekekRoutes);

try{await initialize();
    app.listen(PORT,()=>
    {console.log('Server is running on PORT'`${300}`);
});
} 
catch (err){console.log(err.message);
}

